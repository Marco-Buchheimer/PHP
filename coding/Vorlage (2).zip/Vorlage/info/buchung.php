<?php
$anreise = $_POST["anreise"];
$ueAnzahl = $_POST["naechte"];

$vorname = $_POST["vorname"];
$zuname = $_POST["zuname"];
$straße = $_POST["straße"];
$hnummer = $_POST["Hnummer"];
$plz = $_POST["plz"];
$ort = $_POST["ort"];
$mail = $_POST["mail"];
$telefon = $_POST["telefon"];

$Anz_Erw = $_POST["Anz_Erw"];
?>


<!DOCTYPE html>

<html lang="de">
<head>
    <meta charset="utf-8">

    <title>Hotel Vallora - Online Buchung</title>

    <link rel="stylesheet" type="text/css" href="../stylesheets/meinestyles.css">

</head>

<body>
<h1>Kostenzusammenstellung des Hotels Vallora</h1>

<?php
echo "<h2>Anzahl der Übernachtungen</h2>";
echo "Anreisedatum: $anreise";
echo "<br>";
echo "Anzahl der Übernachtungen: $ueAnzahl ";


echo "<br> <br>";


echo "<h2>Persönliche Daten und Rechnungsadresse</h2>";
echo "Vorname: $vorname";
echo "<br>";
echo "Nachname: $zuname";
echo "<br>";
echo "Straße: $straße";
echo "<br>";
echo "Hausnummer: $hnummer";
echo "<br>";
echo "PLZ: $plz";
echo "<br>";
echo "Ort: $ort";
echo "<br>";
echo "E-Mail: $mail";
echo "<br>";
echo "Telefon: $telefon";

echo "<br> <br>";

echo "<h2>Anzahl der Gäste</h2>";
echo "<br>";
echo "Erwachsene: $Anz_Erw Preis: XX€";
?>
</body>

</html>


